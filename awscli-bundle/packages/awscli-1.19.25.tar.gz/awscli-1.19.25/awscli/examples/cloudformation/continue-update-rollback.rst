**To retry an update rollback**

The following ``continue-update-rollback`` example resumes a rollback operation from a previously failed stack update. ::

    aws cloudformation continue-update-rollback \
        --stack-name my-stack

This command produces no output.